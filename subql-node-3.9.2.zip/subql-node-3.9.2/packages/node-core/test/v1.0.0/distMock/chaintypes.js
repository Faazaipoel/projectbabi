'use strict';

exports.default = {typesBundle: {}};
